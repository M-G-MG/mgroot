#!/system/bin/sh

find_busybox() {
  for bb in     /data/adb/magisk/busybox     /data/adb/ksu/bin/busybox     /data/adb/ap/bin/busybox     /data/adb/modules/busybox-ndk/system/*/busybox     "$(command -v busybox 2>/dev/null)"; do
    if [ -n "$bb" ] && [ -x "$bb" ]; then
      echo "$bb"
      return 0
    fi
  done
  return 1
}

get_sha256() {
  _file="$1"
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$_file" 2>/dev/null | awk '{print $1}'
  elif [ -n "$BUSYBOX" ]; then
    "$BUSYBOX" sha256sum "$_file" 2>/dev/null | awk '{print $1}'
  else
    echo ""
  fi
}

download_keybox() {
  _url="$1"
  _out="$2"
  _ts="$(date +%s 2>/dev/null || echo 1)"

  case "$_url" in
    *\?*) _fetch_url="${_url}&t=${_ts}" ;;
    *)    _fetch_url="${_url}?t=${_ts}" ;;
  esac

  rm -f "$_out"

  if command -v curl >/dev/null 2>&1; then
    curl -fsSL --connect-timeout 15 --max-time 30 -H "Cache-Control: no-cache" "$_fetch_url" -o "$_out" && return 0
  fi

  if [ -x /system/bin/curl ]; then
    /system/bin/curl -fsSL --connect-timeout 15 --max-time 30 -H "Cache-Control: no-cache" "$_fetch_url" -o "$_out" && return 0
  fi

  if command -v wget >/dev/null 2>&1; then
    wget -q --timeout=25 -O "$_out" "$_fetch_url" && return 0
  fi

  if [ -n "$BUSYBOX" ]; then
    "$BUSYBOX" wget --no-check-certificate -q -T 25 -O "$_out" "$_fetch_url" && return 0
  fi

  return 1
}

validate_keybox() {
  _file="$1"
  [ -s "$_file" ] || return 1
  grep -qi "<html" "$_file" && return 1
  grep -q "404: Not Found" "$_file" && return 1
  grep -q "<AndroidAttestation>" "$_file" || return 1
  grep -q "<Keybox" "$_file" || return 1
  return 0
}

install_keybox_file() {
  _src="$1"
  _dir="$2"
  _dst="$3"

  mkdir -p "$_dir"

  if [ -f "$_dst" ]; then
    _old_hash="$(get_sha256 "$_dst")"
    _new_hash="$(get_sha256 "$_src")"
    if [ -n "$_old_hash" ] && [ "$_old_hash" = "$_new_hash" ]; then
      return 2
    fi
    cp -f "$_dst" "${_dst}.bak"
  fi

  cp -f "$_src" "${_dst}.tmp" || return 1
  chmod 644 "${_dst}.tmp"
  chown 0:0 "${_dst}.tmp" 2>/dev/null
  mv -f "${_dst}.tmp" "$_dst" || return 1

  pkill -f "com.google.android.gms.unstable" 2>/dev/null || true
  return 0
}
