#!/system/bin/sh

. "$MODPATH/config.sh"
. "$MODPATH/common_func.sh"
BUSYBOX="$(find_busybox)"

ui_print "========================================"
ui_print "  AbuAyoub Keybox Updater (OTA)"
ui_print "========================================"

set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/common_func.sh" 0 0 0755
set_perm "$MODPATH/config.sh" 0 0 0644

mkdir -p "$TARGET_DIR"

ui_print "- Fetching latest keybox.xml..."
TMP_KB="$MODPATH/keybox_dl.tmp"
if download_keybox "$KEYBOX_URL" "$TMP_KB" && validate_keybox "$TMP_KB"; then
  install_keybox_file "$TMP_KB" "$TARGET_DIR" "$TARGET_FILE"
  _rc=$?
  cp -f "$TMP_KB" "$MODPATH/keybox.xml"
  rm -f "$TMP_KB"
  if [ "$_rc" -eq 2 ]; then
    ui_print "- Keybox is already up to date."
  elif [ "$_rc" -eq 0 ]; then
    ui_print "- Latest keybox.xml installed successfully!"
  else
    ui_print "! Failed to write keybox.xml."
  fi
else
  rm -f "$TMP_KB"
  ui_print "! Online fetch failed (offline or file not uploaded yet)."
  if validate_keybox "$MODPATH/keybox.xml"; then
    ui_print "- Installing bundled fallback keybox.xml..."
    install_keybox_file "$MODPATH/keybox.xml" "$TARGET_DIR" "$TARGET_FILE"
  fi
fi

ui_print "- Tap 'Action' in Magisk anytime to sync"
ui_print "  the latest keybox.xml automatically."
ui_print "========================================"
