#!/system/bin/sh

TARGET_FILE="/data/adb/tricky_store/keybox.xml"

if [ -f "${TARGET_FILE}.bak" ]; then
  mv -f "${TARGET_FILE}.bak" "$TARGET_FILE"
  chmod 644 "$TARGET_FILE"
fi
