# Direct Raw URL for keybox.xml
KEYBOX_URL="https://raw.githubusercontent.com/M-G-MG/mgroot/main/keybox.xml"

# Target path on device
TARGET_DIR="/data/adb/tricky_store"
TARGET_FILE="$TARGET_DIR/keybox.xml"
