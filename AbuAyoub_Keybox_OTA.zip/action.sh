#!/system/bin/sh

MODDIR="${0%/*}"
. "$MODDIR/config.sh"
. "$MODDIR/common_func.sh"
BUSYBOX="$(find_busybox)"

echo "========================================"
echo "  AbuAyoub Keybox Updater"
echo "========================================"

TMP_KB="$MODDIR/keybox_dl.tmp"

echo "- Checking for new keybox.xml..."
if ! download_keybox "$KEYBOX_URL" "$TMP_KB"; then
  rm -f "$TMP_KB"
  echo "! Download failed. Check internet connection or URL."
  exit 1
fi

echo "- Verifying keybox.xml integrity..."
if ! validate_keybox "$TMP_KB"; then
  rm -f "$TMP_KB"
  echo "! Invalid keybox.xml received (corrupted or 404)."
  echo "- Existing keybox.xml was NOT modified."
  exit 1
fi

install_keybox_file "$TMP_KB" "$TARGET_DIR" "$TARGET_FILE"
RC=$?
cp -f "$TMP_KB" "$MODDIR/keybox.xml" 2>/dev/null
rm -f "$TMP_KB"

if [ "$RC" -eq 2 ]; then
  echo "- You already have the latest keybox.xml!"
elif [ "$RC" -eq 0 ]; then
  echo "- Keybox updated & applied successfully!"
  echo "- Path: $TARGET_FILE"
  echo "- No reboot required."
else
  echo "! Error writing to $TARGET_FILE"
  exit 1
fi

echo "========================================"
